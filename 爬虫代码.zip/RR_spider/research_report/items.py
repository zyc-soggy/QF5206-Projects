# -*- coding: utf-8 -*-

# Define here the models for your scraped items
#
# See documentation in:
# https://doc.scrapy.org/en/latest/topics/items.html

import scrapy

class ResearchReportSpiderItem(scrapy.Item):
    # define the fields for your item here like:
    # name = scrapy.Field()

    # 作为id，唯一主键
    report_id = scrapy.Field()
    # 股票代码
    stock_code = scrapy.Field()
    # 股票名称
    stock_name = scrapy.Field()
    # 日期
    publish_time = scrapy.Field()
    # 作者
    author = scrapy.Field()
    # 研报标题
    title = scrapy.Field()
    # 原文评级
    original_rating = scrapy.Field()
    # 评级变动
    rating_changes = scrapy.Field()
    #
    rating_adjust_mark_type = scrapy.Field()
    # 机构
    org_name = scrapy.Field()
    # 内容
    content = scrapy.Field()
    # pdf链接
    pdf_link = scrapy.Field()
    # 文件名
    filename = scrapy.Field()
    # 文件存储路径
    save_path = scrapy.Field()


    report_subtype = scrapy.Field()

    page_count = scrapy.Field()

